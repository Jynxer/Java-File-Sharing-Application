Use cd to change directory to .../MP1/src/
Execute javac FileShareMain.java
Execute java FileShareMain

Follow given instructions.

An example of correct usage is displayed in the report in the testing screenshots.

Jordan Rowley, 2019.